import React from 'react';
import Main from './source/';

export default class App extends React.Component {
  render() {
    return (
      <Main />
    );
  }
}
