const baseUrl = 'http://172.16.197.58:8000';
export default baseUrl;
