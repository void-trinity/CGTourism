import React, { Component } from 'react';
import { View } from 'react-native';

class Guide extends Component {
  render() {
    return (
      <View />
    );
  }
}

export default Guide;
